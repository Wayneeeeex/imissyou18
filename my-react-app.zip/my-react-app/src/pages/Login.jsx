import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import AppHeader from '../components/AppHeader';
import '../assets/design.css';

function Login() {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    role: 'student'
  });
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    // Clear guest mode when arriving at login page
    localStorage.removeItem('guestMode');
    
    // Check if terms were accepted
    const termsAccepted = localStorage.getItem('termsAccepted') === 'true';
    if (!termsAccepted) {
      navigate('/terms');
    }
  }, [navigate]);

  const validateForm = () => {
    const newErrors = {};

    // Email validation
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    // Password validation
    if (!formData.password) {
      newErrors.password = 'Password is required';
    } else if (formData.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Clear guest mode when logging in
      localStorage.removeItem('guestMode');
      
      // Store user data
      localStorage.setItem('userRole', formData.role);
      localStorage.setItem('isLoggedIn', 'true');
      localStorage.setItem('userEmail', formData.email);
      
      // Redirect based on role
      if (formData.role === 'student') {
        navigate('/dashboard/student');
      } else {
        navigate('/dashboard/faculty');
      }
    } catch (error) {
      alert('Login failed. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));

    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  return (
    <div className="app-container">
      <AppHeader title="LOGIN" />
      
      <div className="app-body">
        <form className="auth-form" onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="email" style={{ color: 'black' }}>Email</label>
            <input 
              type="email" 
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="Enter your email" 
              className={errors.email ? 'error' : ''}
            />
            {errors.email && <span className="error-message">{errors.email}</span>}
          </div>
          <div className="form-group">
            <label htmlFor="password" style={{color: 'black'}}>Password</label>
            <input 
              type="password" 
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="Enter your password" 
              className={errors.password ? 'error' : ''}
            />
            {errors.password && <span className="error-message">{errors.password}</span>}
          </div>
          <div className="form-group">
            <label>Login as:</label>
            <div className="radio-group">
              <input 
                type="radio" 
                id="student-login" 
                name="role" 
                value="student" 
                checked={formData.role === 'student'}
                onChange={handleChange}
              />
              <label htmlFor="student-login"className ="btn btn-primary">Student</label>
              <input 
                type="radio" 
                id="faculty-login" 
                name="role" 
                value="faculty" 
                checked={formData.role === 'faculty'}
                onChange={handleChange}
              />
            <label htmlFor="faculty-login" className="btn btn-primary">Faculty</label>
            </div>
          </div>
          <div className="form-actions">
            <button 
              type="submit" 
              className="btn btn-primary"
              disabled={isSubmitting}
              style={{textAlign: isSubmitting ? 'left' : 'center' }}
            >
              {isSubmitting ? 'Logging in..' : 'Login'}
            </button>
            <Link to="/" className="btn btn-secondary">Back</Link>
          </div>
        </form>
      </div>
    </div>
  );
}

export default Login;