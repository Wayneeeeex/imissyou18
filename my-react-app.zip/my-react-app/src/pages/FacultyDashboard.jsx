import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import AppHeader from '../components/AppHeader';
import ProjectCard from '../components/ProjectCard';

function FacultyDashboard() {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('A-Z');
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    // Search functionality would filter projects in a real implementation
    alert(`Searching for: ${searchTerm}`);
  };

  const handleLogout = () => {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('userRole');
    localStorage.removeItem('userEmail');
    navigate('/login');
  };

  // Filter and sort projects based on search and sort criteria
  const filteredAndSortedProjects = sampleProjects
    .filter(project => 
      project.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      project.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
      project.program.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      switch(sortBy) {
        case 'A-Z':
          return a.title.localeCompare(b.title);
        case 'Z-A':
          return b.title.localeCompare(a.title);
        case 'Date':
          return new Date(b.date) - new Date(a.date);
        case 'Author A-Z':
          return a.author.localeCompare(b.author);
        case 'Author Z-A':
          return b.author.localeCompare(a.author);
        case 'Program':
          return a.program.localeCompare(b.program);
        default:
          return 0;
      }
    });

  return (
    <div className="app-container">
      <AppHeader title="Welcome, Faculty" />
      
      <div className="dashboard-container">
        <div className="dashboard-header">
          <form className="search-bar" onSubmit={handleSearch}>
            <input 
              type="text" 
              placeholder="Search..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <button type="submit" className="search-btn">🔍</button>
          </form>
          <div className="user-actions">
            <button onClick={handleLogout} className="btn btn-logout">Logout</button>
          </div>
        </div>
        
        <div className="dashboard-content">
          <div className="sort-options">
            <label>SORT BY:</label>
            <select 
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
            >
              <option>A-Z</option>
              <option>Z-A</option>
              <option>Date</option>
              <option>Degree Level</option>
              <option>Author A-Z</option>
              <option>Author Z-A</option>
              <option>Program</option>
            </select>
          </div>
          
          <h2 className="section-title">CAPSTONE PROJECTS</h2>
          
          <div className="faculty-actions">
            <Link to="/manage" className="btn btn-primary">Manage Repository</Link>
            <Link to="/projects/view" className="btn btn-secondary">View All Projects</Link>
          </div>
          
          <div className="projects-grid">
            {filteredAndSortedProjects.map(project => (
              <ProjectCard 
                key={project.id} 
                project={project} 
                showFacultyActions={true}
              />
            ))}
          </div>

          {/* Dashboard Stats Section */}
          <div className="dashboard-stats">
            <div className="stat-card">
              <h3>Total Projects</h3>
              <div className="stat-number">{sampleProjects.length}</div>
            </div>
            <div className="stat-card">
              <h3>Pending Review</h3>
              <div className="stat-number">
                {sampleProjects.filter(p => p.status === 'under-review').length}
              </div>
            </div>
            <div className="stat-card">
              <h3>Approved</h3>
              <div className="stat-number">
                {sampleProjects.filter(p => p.status === 'approved').length}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default FacultyDashboard;