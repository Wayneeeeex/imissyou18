import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import AppHeader from '../components/AppHeader';
import UniversityFooter from '../components/UniversityFooter';

function SubmitProject() {
  const [formData, setFormData] = useState({
    title: '',
    authors: '',
    program: '',
    abstract: '',
    document: null
  });
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: files ? files[0] : value
    }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.title.trim()) {
      newErrors.title = 'Project title is required';
    }
    
    if (!formData.authors.trim()) {
      newErrors.authors = 'Author(s) are required';
    }
    
    if (!formData.program) {
      newErrors.program = 'Please select a program';
    }
    
    const wordCount = formData.abstract.split(/\s+/).filter(word => word.length > 0).length;
    if (wordCount < 200) {
      newErrors.abstract = `Abstract must be at least 200 words (currently ${wordCount})`;
    }
    
    if (!formData.document) {
      newErrors.document = 'Please upload a PDF document';
    } else if (formData.document.type !== 'application/pdf') {
      newErrors.document = 'Please upload a PDF file only';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (validateForm()) {
      // In real app, would submit to server
      console.log('Project submitted:', formData);
      alert('Project submitted successfully!');
      navigate('/dashboard/student');
    }
  };

  const wordCount = formData.abstract.split(/\s+/).filter(word => word.length > 0).length;
  const isAbstractValid = wordCount >= 200;

  return (
    <div className="app-container">
      <AppHeader title="SUBMIT CAPSTONE PROJECT" />
      
      <div className="app-body">
        <form className="submission-form" onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="project-title">Project Title</label>
            <input 
              type="text" 
              id="project-title"
              name="title"
              value={formData.title}
              onChange={handleChange}
              placeholder="Enter your project title" 
              className={errors.title ? 'error' : ''}
            />
            {errors.title && <span className="error-message">{errors.title}</span>}
          </div>
          
          <div className="form-group">
            <label htmlFor="authors">Author(s)</label>
            <input 
              type="text" 
              id="authors"
              name="authors"
              value={formData.authors}
              onChange={handleChange}
              placeholder="Enter author names (comma separated)" 
              className={errors.authors ? 'error' : ''}
            />
            {errors.authors && <span className="error-message">{errors.authors}</span>}
          </div>
          
          <div className="form-group">
            <label htmlFor="program">Program</label>
            <select 
              id="program"
              name="program"
              value={formData.program}
              onChange={handleChange}
              className={errors.program ? 'error' : ''}
            >
              <option value="">Select program</option>
              <option value="BSIT-IS">BSIT-IS</option>
              <option value="BSIT-BTM">BSIT-BTM</option>
              <option value="BSCS">BSCS</option>
              <option value="BLIS">BLIS</option>
              <option value="MIT">MIT</option>
              <option value="DIT">DIT</option>
            </select>
            {errors.program && <span className="error-message">{errors.program}</span>}
          </div>
          
          <div className="form-group">
            <label htmlFor="abstract">Abstract (Minimum 200 words)</label>
            <textarea 
              id="abstract"
              name="abstract"
              value={formData.abstract}
              onChange={handleChange}
              rows="8" 
              placeholder="Enter your project abstract..." 
              className={errors.abstract ? 'error' : ''}
            />
            <div className={`word-count ${isAbstractValid ? 'adequate' : 'low'}`}>
              Word count: {wordCount} {!isAbstractValid && `(Need ${200 - wordCount} more words)`}
            </div>
            {errors.abstract && <span className="error-message">{errors.abstract}</span>}
          </div>
          
          <div className="form-group">
            <label htmlFor="document">Upload Document (PDF only)</label>
            <input 
              type="file" 
              id="document"
              name="document"
              onChange={handleChange}
              accept=".pdf" 
            />
            {formData.document && (
              <div className="file-info">
                Selected file: {formData.document.name}
              </div>
            )}
            {errors.document && <span className="error-message">{errors.document}</span>}
          </div>
          
          <div className="form-actions">
            <button type="submit" className="btn btn-primary">Submit Project</button>
            <Link to="/dashboard/student" className="btn btn-secondary">Cancel</Link>
          </div>
        </form>
      </div>
      
      <UniversityFooter />
    </div>
  );
}

export default SubmitProject;