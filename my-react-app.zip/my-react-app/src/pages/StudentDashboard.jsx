import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import AppHeader from '../components/AppHeader';
import Breadcrumbs from '../components/Breadcrumbs';
import '../assets/design.css';


function StudentDashboard() {
  const [currentView, setCurrentView] = useState('folders');
  const [currentCourse, setCurrentCourse] = useState('');
  const [breadcrumbs, setBreadcrumbs] = useState([{ name: 'My Courses', path: 'folders' }]);
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();

  const showCourse = (course) => {
    setCurrentView('projects');
    setCurrentCourse(course);
    setBreadcrumbs([
      { name: 'My Courses', path: 'folders' },
      { name: course, path: course }
    ]);
  };

  const showRootFolder = () => {
    setCurrentView('folders');
    setCurrentCourse('');
    setBreadcrumbs([{ name: 'My Courses', path: 'folders' }]);
  };

  const viewProject = (projectId) => {
    alert(`Viewing project ${projectId} in ${currentCourse}`);
    // In real implementation, would open project detail view
    // navigate(`/abstract/${projectId}`);
  };

  const editProject = (projectId) => {
    alert(`Editing project ${projectId} in ${currentCourse}`);
    // In real implementation, would open edit form
  };

  const submitForReview = (projectId) => {
    if (window.confirm("Submit this project for faculty review?")) {
      alert(`Project ${projectId} submitted for review`);
      // In real app, would update via API
    }
  };

  const getStatusBadge = (status) => {
    const badges = {
      'draft': '✏️ Draft',
      'submitted': '🕒 Under Review',
      'approved': '✅ Approved',
      'rejected': '❌ Needs Revision'
    };
    return badges[status] || status;
  };

  const handleLogout = () => {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('userRole');
    navigate('/login');
  };

  const handleSearch = (e) => {
    e.preventDefault();
    // Search functionality would be implemented here
    alert(`Searching for: ${searchTerm}`);
  };

  return (
    <div className="app-container">
      <AppHeader title="Welcome, Student" />
      
      <div className="dashboard-container">
        <div className="dashboard-header">
          <form className="search-bar" onSubmit={handleSearch}>
            <input 
              type="text" 
              placeholder="Search courses or projects..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <button type="submit" className="search-btn">🔍</button>
          </form>
          <div className="user-actions">
            <button onClick={handleLogout} className="btn btn-quit">Logout</button>
          </div>
        </div>
        
        <div className="dashboard-content">
          <Breadcrumbs items={breadcrumbs} onNavigate={showRootFolder} />
          
          {currentView === 'folders' && (
            <div id="folderView">
              <h2 className="section-title">My Courses</h2>
              <div className="folder-view">
                {/* BSIT-IS Folder */}
                <div className="folder" onClick={() => showCourse('BSIT-IS')}>
                  <div className="folder-icon">📁</div>
                  <div className="folder-name">BSIT-IS</div>
                  <div className="folder-info">12 projects</div>
                </div>
                
                {/* BSIT-BTM Folder */}
                <div className="folder" onClick={() => showCourse('BSIT-BTM')}>
                  <div className="folder-icon">📁</div>
                  <div className="folder-name">BSIT-BTM</div>
                  <div className="folder-info">8 projects</div>
                </div>
                
                {/* BSCS Folder */}
                <div className="folder" onClick={() => showCourse('BSCS')}>
                  <div className="folder-icon">📁</div>
                  <div className="folder-name">BSCS</div>
                  <div className="folder-info">15 projects</div>
                </div>
                
                {/* MIT Folder */}
                <div className="folder" onClick={() => showCourse('MIT')}>
                  <div className="folder-icon">📁</div>
                  <div className="folder-name">MIT</div>
                  <div className="folder-info">5 projects</div>
                </div>
              </div>
            </div>
          )}
          
          {currentView === 'projects' && (
            <div id="projectView" className="project-view">
              <button className="btn btn-secondary back-to-folders" onClick={showRootFolder}>
                ← Back to Courses
              </button>
              
              <h2 className="section-title">{currentCourse} Projects</h2>
              
              <div className="projects-grid">
                {courses[currentCourse]?.map(project => (
                  <div key={project.id} className="project-card">
                    <div className="project-badge">{project.type === 'Capstone' ? '📄' : '📑'}</div>
                    <h3>{project.title}</h3>
                    <p>{project.type} Project</p>
                    <p className="author">Author: {project.author}</p>
                    <div className="project-status">
                      Status: <span id={`status-${project.id}`}>{getStatusBadge(project.status)}</span>
                    </div>
                    <div className="action-buttons">
                      <button className="btn btn-view" onClick={() => viewProject(project.id)}>View</button>
                      {project.author === 'You' && (
                        <>
                          <button className="btn btn-edit" onClick={() => editProject(project.id)}>Edit</button>
                          {project.status === 'draft' && (
                            <button className="btn btn-primary" onClick={() => submitForReview(project.id)}>
                              Submit for Review
                            </button>
                          )}
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          <div style={{ marginTop: '20px', textAlign: 'center' }}>
            <Link to="/submit" className="btn btn-primary">Submit New Project</Link>
          </div>
        </div>
      </div>
    </div>
  );
}

export default StudentDashboard;