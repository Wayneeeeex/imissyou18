import React from 'react';
import { Link, useParams } from 'react-router-dom';
import AppHeader from '../components/AppHeader';
import GuestNotice from '../components/GuestNotice';
import UniversityFooter from '../components/UniversityFooter';

function ProjectAbstract({ guestMode }) {
  const { id } = useParams();
  const project = sampleProjects.find(p => p.id === parseInt(id));

  if (!project) {
    return <div>Project not found</div>;
  }

  return (
    <div className="app-container">
      <AppHeader title="PROJECT ABSTRACT" />
      
      <div className="app-body">
        <GuestNotice guestMode={guestMode} />
        
        <div className="abstract-container">
          <h2>{project.title}</h2>
          <div className="abstract-content">
            <p><strong>Author:</strong> {project.author}</p>
            <p><strong>Program:</strong> {project.program}</p>
            <p><strong>Type:</strong> {project.type}</p>
            <p><strong>Date:</strong> {project.date}</p>
            <hr />
            <p>{project.excerpt}</p>
            <p>This is a detailed abstract of the project. In a real application, this would contain the complete abstract text from the database.</p>
          </div>
          
          <div className="document-actions">
            <button className="btn btn-primary">Download PDF</button>
            <button className="btn btn-secondary">View Full Document</button>
          </div>
        </div>
        
        <div className="back-link">
          <Link 
            to={guestMode ? "/projects?guest=true" : "/projects"} 
            className="btn btn-secondary"
          >
            Back to Projects
          </Link>
        </div>
      </div>
      
      <UniversityFooter />
    </div>
  );
}

export default ProjectAbstract;