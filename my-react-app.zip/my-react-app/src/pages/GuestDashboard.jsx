import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import AppHeader from '../components/AppHeader';

function GuestDashboard() {
  const [programFilter, setProgramFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const navigate = useNavigate();

  // Sample projects data for guest view
  const sampleProjects = [
    {
      id: 1,
      title: "AI Student Performance Predictor",
      type: "Capstone Project",
      program: "BSIT-IS",
      author: "Juan Dela Cruz",
      date: "May 20, 2023",
      excerpt: "An AI-powered system for predicting student academic performance using machine learning algorithms..."
    },
    {
      id: 2,
      title: "Business Analytics Dashboard",
      type: "Capstone Project",
      program: "BSIT-BTM",
      author: "Maria Santos",
      date: "June 15, 2023",
      excerpt: "A comprehensive business intelligence dashboard for small and medium enterprises..."
    },
    {
      id: 3,
      title: "Blockchain Voting System",
      type: "Thesis Project",
      program: "BSCS",
      author: "John Smith",
      date: "April 10, 2023",
      excerpt: "A secure and transparent voting system built on blockchain technology..."
    },
    {
      id: 4,
      title: "E-Learning Platform",
      type: "Capstone Project",
      program: "MIT",
      author: "Robert Johnson",
      date: "July 5, 2023",
      excerpt: "A modern e-learning platform with interactive courses and progress tracking..."
    },
    {
      id: 5,
      title: "Library Management System",
      type: "Thesis Project",
      program: "MLIS",
      author: "Sarah Williams",
      date: "March 22, 2023",
      excerpt: "A digital library management system with advanced search and recommendation features..."
    },
    {
      id: 6,
      title: "Data Analytics Framework",
      type: "Capstone Project",
      program: "DIT",
      author: "Michael Brown",
      date: "August 12, 2023",
      excerpt: "A framework for big data analytics and visualization in enterprise environments..."
    }
  ];

  // Filter projects based on program and search term
  const filteredProjects = sampleProjects.filter(project => {
    const matchesProgram = programFilter === 'all' || project.program === programFilter;
    const matchesSearch = project.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         project.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         project.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesProgram && matchesSearch;
  });

  // Pagination
  const projectsPerPage = 4;
  const totalPages = Math.ceil(filteredProjects.length / projectsPerPage);
  const startIndex = (currentPage - 1) * projectsPerPage;
  const paginatedProjects = filteredProjects.slice(startIndex, startIndex + projectsPerPage);

  useEffect(() => {
    // Set guest mode when component mounts
    localStorage.setItem('guestMode', 'true');
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    setCurrentPage(1); // Reset to first page when searching
  };

  const filterProjects = () => {
    setCurrentPage(1); // Reset to first page when filtering
  };

  const resetFilters = () => {
    setProgramFilter('all');
    setSearchTerm('');
    setCurrentPage(1);
  };

  const viewProject = (id) => {
    navigate(`/abstract/${id}`);
  };

  const goToPreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const goToNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  return (
    <div className="app-container">
      <AppHeader title="Guest Access" />
      
      <div className="dashboard-container">
        <div className="dashboard-header">
          <form className="search-bar" onSubmit={handleSearch}>
            <input 
              type="text" 
              placeholder="Search projects..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <button type="submit" className="search-btn">🔍</button>
          </form>
          <div className="user-actions">
            <Link to="/login" className="btn btn-primary">Login</Link>
          </div>
        </div>
        
        <div className="dashboard-content">
          <div className="view-only-notice">
            <p>You are browsing as a guest. Login to access all features.</p>
          </div>
          
          <div className="sort-options">
            <label style={{ marginLeft: '15px' }}>Program:</label>
            <select 
              id="programSelect"
              value={programFilter}
              onChange={(e) => {
                setProgramFilter(e.target.value);
                filterProjects();
              }}
            >
              <option value="all">All Programs</option>
              <option value="BSIT-IS">BSIT-IS</option>
              <option value="BSIT-BTM">BSIT-BTM</option>
              <option value="BSCS">BSCS</option>
              <option value="MIT">MIT</option>
              <option value="DIT">DIT</option>
            </select>
          </div>
          
          <div className="guest-actions">
            <button className="btn btn-secondary" onClick={filterProjects}>Apply Filters</button>
            <button className="btn btn-secondary" onClick={resetFilters}>Reset</button>
          </div>
          
          <div className="projects-grid">
            {paginatedProjects.map(project => (
              <div key={project.id} className="project-card">
                <div className="project-badge">📄</div>
                <h3>{project.title}</h3>
                <p>{project.program} {project.type}</p>
                <p className="author">By: {project.author}</p>
                <p className="date">Published: {project.date}</p>
                <div className="project-excerpt">
                  {project.excerpt}
                </div>
                <div className="actions">
                  <button 
                    className="btn btn-view" 
                    onClick={() => viewProject(project.id)}
                  >
                    View Abstract
                  </button>
                </div>
              </div>
            ))}
          </div>
          
          <div className="pagination">
            <button 
              className="btn btn-secondary" 
              onClick={goToPreviousPage}
              disabled={currentPage === 1}
            >
              Previous
            </button>
            <span>Page {currentPage} of {totalPages}</span>
            <button 
              className="btn btn-secondary" 
              onClick={goToNextPage}
              disabled={currentPage === totalPages}
            >
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default GuestDashboard;